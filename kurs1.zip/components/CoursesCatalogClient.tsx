"use client";

import { instructors, type  Course } from "@/lib/data";
import { useMemo, useState } from "react";
import CourseCard from "./CourseCard";

function instructorNameForCourse(course: Course): string {
    return (
        instructors.find((i) => i.slug === course.instructorSlug)?.name ?? "Unknown Instructor"
    )
}

export default function CoursesCatalogClient({ courses, categories, levels }: { courses: Course[]; categories: string[], levels: string[] }) {
    const [level, setLevel] = useState<string>("all");
    const [category, setCategory] = useState<string>("all");
    const [query, setQuery] = useState<string>("");
    
    const filtered = useMemo(() => {
        const q = query.trim().toLowerCase();
        return courses.filter((course) => {
            const matchesQuery = q === "" || course.title.toLowerCase().includes(q);
            const matchesCategory = category === "all" || course.category === category;
            const matchesLevel = level === "all" || course.level === level;
            return matchesQuery && matchesCategory && matchesLevel;
        })
    }, [query, courses,category, level])

    const resetFilters = () => {
        setQuery("");
        setCategory("all");
        setLevel("all");
    }

    const isFiltering = query !== "" || category !== "all" || level !== "all";

    return (
        <div className="stack-md">
            <div className="panel">
                <div className="grid-filters">
                    <div className="field">
                        <label htmlFor="course-search" className="field-label">
                            Search by title
                        </label>
                        <input id="course-search" type="text" className="input" placeholder="e.g. Next.js" onChange={(e) => setQuery(e.target.value)}
                            value={query} />
                    </div>
                    <div className="field">
                        <label htmlFor="course-category" className="field-label">
                            Filter by category
                        </label>
                        <select id="course-category" className="select" onChange={(e) => setCategory(e.target.value)} value={category}>
                            <option value="all">All categories</option>
                            {categories.map((category) => (
                                <option value={category} key={category}>{category}</option>
                            ))}
                        </select>
                    </div>
                    <div className="field">
                        <label htmlFor="course-level" className="field-label">
                            Filter by level
                        </label>
                        <select id="course-level" className="select" onChange={(e) => setLevel(e.target.value)} value={level}>
                            <option value="all">All levels</option>
                            {levels.map((level) => (
                                <option value={level} key={level}>{level}</option>
                            ))}
                        </select>
                    </div>
                </div>
                <div className="filter-bar">
                    {isFiltering ? (<button className="btn-link" onClick={resetFilters}>Reset Filters</button>) : null}
                </div>
            </div>
            <div className="grid-cards">
                {filtered.map((course) => (
                    <CourseCard key={course.id} course={course} instructorName={instructorNameForCourse(course)} />
                ))}
            </div>
        </div>
    )
}